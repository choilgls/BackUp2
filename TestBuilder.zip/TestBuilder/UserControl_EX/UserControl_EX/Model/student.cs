﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace UserControl_EX.Model
{
    public class student:INotifyPropertyChanged
    {
        static public ObservableCollection<student> S_StudentList = new ObservableCollection<student>();

        public student(string name, string gender, int age, string grade)
        {

            Name = name;
            Gender = gender;
            Age = age;
            Grade = grade;
            Random_TestNum= NewNumber(age);
        }

        
        private string name { get; set; }
        private string gender{ get; set; }
        private int age{ get; set; }
        private string grade{ get; set; }

        private int random_TestNum { get; set; }


        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }

        public string Gender
        {
            get { return gender; }
            set
            {
                if (gender != value)
                {
                    gender = value;
                    OnPropertyChanged(nameof(Gender));
                }
            }
        }

        public int Age
        {
            get { return age; }
            set
            {
                if (age != value)
                {
                    age = value;
                    OnPropertyChanged(nameof(Age));
                }
            }
        }

        public string Grade
        {
            get { return grade; }
            set
            {
                if (grade != value)
                {
                    grade = value;
                    OnPropertyChanged(nameof(Grade));
                }
            }
        }

        public int Random_TestNum
        {
            get { return random_TestNum; }
            set
            {
                if (random_TestNum != value)
                {
                    random_TestNum = value;
                    OnPropertyChanged(nameof(Random_TestNum));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public int NewNumber(int num)
        {
            Random rand = new Random();
            return rand.Next(num);
        }
    }
}
