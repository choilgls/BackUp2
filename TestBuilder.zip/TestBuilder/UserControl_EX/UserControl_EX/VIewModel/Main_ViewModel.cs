﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using UserControl_EX.Common;
using UserControl_EX.Model;
using static UserControl_EX.Model.student;

namespace UserControl_EX.VIewModel
{
    public class Main_ViewModel : ViewModelBase
    {
        public ICommand ResetCommand { get; private set; }   //Reset Random Value
        public ObservableCollection<student> StudentList { get { return S_StudentList; } set { S_StudentList = value; OnPropertyChanged("StudentList"); } }
        public Main_ViewModel()
        {
            ResetCommand = new RelayCommad<Object>(ResetCommandMethod);

            StudentList.Add(new student("최지훈", "남성", 27, "직장인"));
            StudentList.Add(new student("신짱구", "남성", 25, "직장인"));
            StudentList.Add(new student("김철수", "남성", 16, "학생"));
            StudentList.Add(new student("김유리", "여성", 13, "학생"));
        }


        private void ResetCommandMethod(object parameter)
        {
            ObservableCollection<student> NewStudentList=new ObservableCollection<student>();
            int index = 0;
            foreach (student student in S_StudentList)
            {
                student.Random_TestNum = student.NewNumber(student.Age);
                MessageBox.Show(student.Name + ":" + student.Random_TestNum.ToString());
            }
          /* foreach(student student in StudentList)
            {
                NewStudentList.Add(new student(student.Name, student.Gender,student.Age, student.Grade));
                NewStudentList[index].Random_TestNum = NewStudentList[index].NewNumber(student.Age);
                MessageBox.Show(NewStudentList[index].Name+":"+ NewStudentList[index].Random_TestNum.ToString());
                index++;
            }
            StudentList = NewStudentList;*/
            DispatcherService.Invoke((System.Action)(() =>
            {
                OnPropertyChanged("StudentList");
            }));
        }



    }
}
