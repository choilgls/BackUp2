﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Viewer.View.Monitoring
{
    /// <summary>
    /// UC_Info.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Info : UserControl
    {
        public UC_Info()
        {
            InitializeComponent();
        }

        public static readonly DependencyProperty UC_NameProperty = DependencyProperty.Register(
         "UC_Name", typeof(string), typeof(UC_Info), new PropertyMetadata(string.Empty));
        public string UC_Name
        {
            get { return (string)GetValue(UC_NameProperty); }
            set { SetValue(UC_NameProperty, value); }
        }



        public static readonly DependencyProperty UC_ContentProperty = DependencyProperty.Register(
         "UC_Content", typeof(string), typeof(UC_Info), new PropertyMetadata(string.Empty));
        public string UC_Content
        {
            get { return (string)GetValue(UC_ContentProperty); }
            set { SetValue(UC_ContentProperty, value); }
        }
    }
}
