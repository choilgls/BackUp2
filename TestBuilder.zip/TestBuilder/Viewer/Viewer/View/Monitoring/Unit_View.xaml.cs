﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Viewer.View.Monitoring
{
    /// <summary>
    /// Unit_View.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Unit_View : UserControl
    {
        public Unit_View()
        {
            InitializeComponent();
        }
        public static readonly DependencyProperty UC_NameProperty = DependencyProperty.Register(
         "UC_Name", typeof(string), typeof(Unit_View), new PropertyMetadata(string.Empty));
        public string UC_Name
        {
            get { return (string)GetValue(UC_NameProperty); }
            set { SetValue(UC_NameProperty, value); }
        }



        public static readonly DependencyProperty UC_SubNameProperty = DependencyProperty.Register(
         "UC_SubName", typeof(string), typeof(Unit_View), new PropertyMetadata(string.Empty));
        public string UC_SubName
        {
            get { return (string)GetValue(UC_SubNameProperty); }
            set { SetValue(UC_SubNameProperty, value); }
        }

        public static readonly DependencyProperty UC_WarningProperty = DependencyProperty.Register(
         "UC_Warning", typeof(string), typeof(Unit_View), new PropertyMetadata(string.Empty));
        public string UC_Warning
        {
            get { return (string)GetValue(UC_WarningProperty); }
            set { SetValue(UC_WarningProperty, value); }
        }
    }
}
