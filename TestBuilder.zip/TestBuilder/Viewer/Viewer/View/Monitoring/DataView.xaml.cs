﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Viewer.Common.Mediator1;
namespace Viewer.View.Monitoring
{
    /// <summary>
    /// Data_View.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Data_View : Page
    {
        public Data_View()
        {
            InitializeComponent();
            this.DataContext = system_ViewModel;
        }
    }
}
