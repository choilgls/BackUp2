﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Viewer.Model;
using Viewer.View.Monitoring;

namespace Viewer.View.Setting
{
    /// <summary>
    /// UC_Data1.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Data1 : UserControl
    {
        public UC_Data1()
        {
            InitializeComponent();
        }
        public static readonly DependencyProperty Info1Property = DependencyProperty.Register(
         "Info1", typeof(MonitoringData), typeof(UC_Data1), new PropertyMetadata(null));
        public MonitoringData Info1
        {
            get { return (MonitoringData)GetValue(Info1Property); }
            set { SetValue(Info1Property, value); }
        }
    }
}
