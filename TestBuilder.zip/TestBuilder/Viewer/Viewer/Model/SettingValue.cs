﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Viewer.Model
{
    public class SettingValue : INotifyPropertyChanged
    {
        private int low { get; set; }

        private int high { get; set; }

        public int Low
        {
            get { return low; }
            set
            {
                if (low != value)
                {
                    low = value;
                    OnPropertyChanged(nameof(Low));
                }
            }
        }
        public int High
        {
            get { return high; }
            set
            {
                if (high != value)
                {
                    high = value;
                    OnPropertyChanged(nameof(High));
                }
            }
        }


        public SettingValue(int low, int high)
        {
            Low = low;
            High = high;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
