﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Viewer.Common;
using static Viewer.Common.Mediator1;
using static Viewer.Model.MonitoringData;

namespace Viewer.Model
{
    public class IOM_Info : INotifyPropertyChanged
    {
        private string name { get; set; }
        private string subName { get; set; }
        private string ip { get; set; }
        private string description { get; set; }
        private string warning { get; set; }
        private int id { get; set; }
        private MonitoringData data { get; set; }

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public string SubName
        {
            get { return subName; }
            set
            {
                if (subName != value)
                {
                    subName = value;
                    OnPropertyChanged(nameof(SubName));
                }
            }
        }
        public string IP
        {
            get { return ip; }
            set
            {
                if (ip != value)
                {
                    ip = value;
                    OnPropertyChanged(nameof(IP));
                }
            }
        }
        public string Description
        {
            get { return description; }
            set
            {
                if (description != value)
                {
                    description = value;
                    OnPropertyChanged(nameof(Description));
                }
            }
        }
        public string Warning
        {
            get { return warning; }
            set
            {
                if (warning != value)
                {
                    warning = value;
                    OnPropertyChanged(nameof(Warning));
                }
            }
        }
        public int ID
        {
            get { return id; }
            set
            {
                if (id != value)
                {
                    id = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }
        public MonitoringData Data
        {
            get { return data; }
            set
            {
                if (data != value)
                {
                    data = value;
                    OnPropertyChanged(nameof(Data));
                }
            }
        }

        static public ObservableCollection<IOM_Info> IOM_List=new ObservableCollection<IOM_Info>();
        static public IOM_Info EWS=new IOM_Info("EWS","(PC)","192.168.0.148", "Engineering WorkStation",100);
        public ICommand ShowInfoCommand { get; private set; }   //Change Page(View) & Show Info
        public IOM_Info(string name, string subName, string iP, string description,int id)
        {
            ShowInfoCommand = new RelayCommad<Object>(ShowInfoCommandMethod);
            Name = name;
            IP = iP;
            Description = description;
            SubName = subName;
            Warning = "---";
            ID = id;
            Data = new MonitoringData(Name+subName);
        }
        private void ShowInfoCommandMethod(object parameter)
        {
            NotifyColleagues("SHOWINFO", "asd");
            foreach (var item in IOM_List)
            {
                if(item.IP== parameter as string)
                    NotifyColleagues("SETINFO", item);
            }
            
        }


        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
