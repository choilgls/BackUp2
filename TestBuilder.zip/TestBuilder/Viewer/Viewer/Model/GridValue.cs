﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Viewer.Model
{
    public class GridValue :ViewModelBase
    {
        private string _pageName;
        public string PageName { get { return _pageName; } set { _pageName = value; OnPropertyChanged("PageName"); } }

        private string _pageSource;
        public string PageSource { get { return _pageSource; } set { _pageSource = value; OnPropertyChanged("PageSource"); } }

        private string _v1Value;                                  
        public string V1Value { get { return _v1Value; } set { _v1Value = value; OnPropertyChanged("V1Value"); } }

        private string _spValue;                                  
        public string SPValue { get { return _spValue; } set { _spValue = value; OnPropertyChanged("SPValue"); } }

        private string _v2Value;                                  
        public string V2Value { get { return _v2Value; } set { _v2Value = value; OnPropertyChanged("V2Value"); } }

        public GridValue(string v1Value, string sPValue, string v2Value)
        {
            
            this.V1Value = v1Value;
            this.SPValue = sPValue;
            this.V2Value = v2Value;
            this.PageName = "SystemView";
        }
        public void SetValue(string v1Value, string sPValue, string v2Value)
        {
            this.V1Value = v1Value;
            this.SPValue = sPValue;
            this.V2Value = v2Value;
        }
        public void SetPageSource()
        {
            this.PageSource= "Monitoring/" + this.PageName+ ".xaml";
        }
        public void SetPageName(string name)
        {
            this.PageName= name;
            SetPageSource();
        }
    }
}
