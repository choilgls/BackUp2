﻿using Microsoft.Expression.Interactivity.Core;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static Viewer.Model.SettingValue;

namespace Viewer.Model
{
    public class MonitoringData : INotifyPropertyChanged
    {
        public MonitoringData(string name)
        {
            Name = name;
            IsRunning = false;
            InfoPortState = "비정상";
            ControlPortState = "비정상";
            BackPortState = "비정상";
            Memory = 0;
            Data1 = 0;
            Data2 =0;
            Data3 = 0;
            SettingValue_Memory = new SettingValue(1024, 2048);
            SettingValue_Data1 = new SettingValue(10, 20);
            SettingValue_Data2 = new SettingValue(100, 200);
            SettingValue_Data3 = new SettingValue(1000, 2000);
        }

        private string name { get; set; }      //true false
        private int id { get; set; }    //1000~2000
        private bool isRunning { get; set; }      //true false
        private string infoPortState { get; set; }      //정상 비정상
        private string controlPortState { get; set; }    //정상 비정상
        private string backPortState { get; set; }    //정상 비정상
        private double memory { get; set; }       //1024 ~ 2048
        private int data1 { get; set; }    //10~20
        private int data2 { get; set; }    //100~200
        private int data3 { get; set; }    //1000~2000

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public int ID
        {
            get { return id; }
            set
            {
                if (id != value)
                {
                    id = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }
        public bool IsRunning
        {
            get { return isRunning; }
            set
            {
                if (isRunning != value)
                {
                    isRunning = value;
                    OnPropertyChanged(nameof(IsRunning));
                }
            }
        }
        public string InfoPortState
        {
            get { return infoPortState; }
            set
            {
                if (infoPortState != value)
                {
                    infoPortState = value;
                    OnPropertyChanged(nameof(InfoPortState));
                }
            }
        }
        public string ControlPortState
        {
            get { return controlPortState; }
            set
            {
                if (controlPortState != value)
                {
                    controlPortState = value;
                    OnPropertyChanged(nameof(ControlPortState));
                }
            }
        }
        public string BackPortState
        {
            get { return backPortState; }
            set
            {
                if (backPortState != value)
                {
                    backPortState = value;
                    OnPropertyChanged(nameof(BackPortState));
                }
            }
        }
        public double Memory
        {
            get { return memory; }
            set
            {
                if (memory != value)
                {
                    memory = value;
                    OnPropertyChanged(nameof(Memory));
                }
            }
        }
        public int Data1
        {
            get { return data1; }
            set
            {
                if (data1 != value)
                {
                    data1 = value;
                    OnPropertyChanged(nameof(Data1));
                }
            }
        }
        public int Data2
        {
            get { return data2; }
            set
            {
                if (data2 != value)
                {
                    data2 = value;
                    OnPropertyChanged(nameof(Data2));
                }
            }
        }
        public int Data3
        {
            get { return data3; }
            set
            {
                if (data3 != value)
                {
                    data3 = value;
                    OnPropertyChanged(nameof(Data3));
                }
            }
        }

        private SettingValue settingValue_Memory { get; set; }
        private SettingValue settingValue_Data1 { get; set; }
        private SettingValue settingValue_Data2 { get; set; }    //10~20
        private SettingValue settingValue_Data3 { get; set; }    //10~20

        public SettingValue SettingValue_Memory
        {
            get { return settingValue_Memory; }
            set
            {
                if (settingValue_Memory != value)
                {
                    settingValue_Memory = value;
                    OnPropertyChanged(nameof(SettingValue_Memory));
                }
            }
        }
        public SettingValue SettingValue_Data1
        {
            get { return settingValue_Data1; }
            set
            {
                if (settingValue_Data1 != value)
                {
                    settingValue_Data1 = value;
                    OnPropertyChanged(nameof(SettingValue_Data1));
                }
            }
        }
        public SettingValue SettingValue_Data2
        {
            get { return settingValue_Data2; }
            set
            {
                if (settingValue_Data2 != value)
                {
                    settingValue_Data2 = value;
                    OnPropertyChanged(nameof(SettingValue_Data2));
                }
            }
        }
        public SettingValue SettingValue_Data3
        {
            get { return settingValue_Data3; }
            set
            {
                if (settingValue_Data3 != value)
                {
                    settingValue_Data3 = value;
                    OnPropertyChanged(nameof(SettingValue_Data3));
                }
            }
        }

        public MonitoringData DeepCopy()
        {
            MonitoringData newdata = new MonitoringData(this.Name);
            newdata.Name = this.Name;
            newdata.IsRunning = this.IsRunning;
            newdata.InfoPortState = this.InfoPortState;
            newdata.ControlPortState = this.ControlPortState;
            newdata.BackPortState = this.BackPortState;
            newdata.Memory = this.Memory;
            newdata.Data1 = this.Data1;
            newdata.Data2 = this.Data2;
            newdata.Data3 = this.Data3;
            newdata.SettingValue_Memory = new SettingValue(this.SettingValue_Memory.Low, this.SettingValue_Memory.High);
            newdata.SettingValue_Data1 = new SettingValue(this.SettingValue_Data1.Low, this.SettingValue_Data1.High);
            newdata.SettingValue_Data2 = new SettingValue(this.SettingValue_Data2.Low, this.SettingValue_Data2.High);
            newdata.SettingValue_Data3 = new SettingValue(this.SettingValue_Data3.Low, this.SettingValue_Data3.High);
            return newdata;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
