﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Viewer.Common;
using Viewer.Model;
using static Viewer.Common.Mediator1;
using static Viewer.Model.IOM_Info;

namespace Viewer.ViewModel
{
    public class Data_ViewModel : ViewModelBase
    {
        
        public ObservableCollection<IOM_Info> IOMLIST { get { return IOM_List; } set { IOM_List = value; OnPropertyChanged("IOMLIST"); } }
        private ObservableCollection<MonitoringData> Sub_IOMLIST=new ObservableCollection<MonitoringData>();

        private MonitoringData _thema;
        public MonitoringData Thema { get { return _thema; } set { _thema = value; OnPropertyChanged("Thema"); } }

        
        public ICommand BtnCommand { get; private set; }   //Change Page(View)
        public Data_ViewModel()
        {
            BtnCommand = new RelayCommad<Object>(BtnCommandMethod);

            Sub_IOMLIST.Add(IOMLIST[0].Data.DeepCopy());
            Sub_IOMLIST.Add(IOMLIST[1].Data.DeepCopy());
            Sub_IOMLIST.Add(IOMLIST[2].Data.DeepCopy());
            Sub_IOMLIST.Add(IOMLIST[3].Data.DeepCopy());
            Sub_IOMLIST.Add(IOMLIST[4].Data.DeepCopy());
            IOMLIST.CollectionChanged += OnIOMListCollectionChanged;
            

            ShowInfoCommand = new RelayCommad<Object>(ShowInfoCommandMethod);
        }
        private void OnIOMListCollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            // IOM_List의 데이터가 변경될 때마다 UI 업데이트
            OnPropertyChanged("IOMLIST");
        }
        private void BtnCommandMethod(object parameter)
        {
            string str = parameter as string;
            if (str == "N")
            {
                IOMLIST[0].Data = Sub_IOMLIST[0];
                IOMLIST[1].Data = Sub_IOMLIST[1];
                IOMLIST[2].Data = Sub_IOMLIST[2];
                IOMLIST[3].Data = Sub_IOMLIST[3];
                IOMLIST[4].Data = Sub_IOMLIST[4];
            }           
            Window CurrentWindow = Application.Current.MainWindow;
            
            CurrentWindow.Close();
            NotifyColleagues("SETTINGEXITINDEX", "0");
            NotifyColleagues("DATAUPDATE", "0");
        }




        public ICommand ShowInfoCommand { get; private set; }   //Change Page(View) & Show Info
        private void ShowInfoCommandMethod(object parameter)
        {
            NotifyColleagues("SHOWINFO", "asd");
            NotifyColleagues("SETINFO", EWS);

        }
    }
}
