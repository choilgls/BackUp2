﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using Viewer.Common;
using Viewer.Model;
using static Viewer.Common.Mediator1;

namespace Viewer.ViewModel
{
    public class Log_ViewModel : ViewModelBase
    {
        
        private ObservableCollection<Log> _aLLLogList = new ObservableCollection<Log>();
        public ObservableCollection<Log> ALLLogList { get { return _aLLLogList; } set { _aLLLogList = value; OnPropertyChanged("ALLLogList"); } }

        private ObservableCollection<string> _filterOptions = new ObservableCollection<string>();
        public ObservableCollection<string> FilterOptions { get { return _filterOptions; } set { _filterOptions = value; OnPropertyChanged("FilterOptions"); } }
        private CollectionViewSource logSource { get; set; }
        public ObservableCollection<Log> FilteredItems;
        public ICollectionView LogSource
        {
            get { return logSource.View; }
        }

        public ICommand ButtonCommand { get; private set; }   //Change Page(View)

        public Log_ViewModel()
        {

            ButtonCommand = new RelayCommad<Object>(ButtonCommandMethod);
            FilterOptions = new ObservableCollection<string>
            {
                "All",
                "System Monitoring",
                "Setting"   ,
                "Log"
            };
            logSource = new CollectionViewSource();
            FilteredItems = ALLLogList;
            logSource.Source = FilteredItems;
            Register("ADDLOG", AddLog);
            NotifyColleagues("ADDLOG", "Log!@#Test Message ");
        }
        public void AddLog(object obj)
        {
            string? str = obj.ToString();
            string[] split_data = str.Split("!@#");
            DateTime time = DateTime.Now;
            DispatcherService.Invoke((System.Action)(() =>
            {
                ALLLogList.Add(new Log(split_data[0], split_data[1], time.ToString("HH : mm : ss"), time.ToString("yyyy-MM-dd")));
            }));
        }
        private void ButtonCommandMethod(object parameter)
        {
            string str = parameter as string;
            NotifyColleagues("ADDLOG", "Log!@#"+str +"Clicked");
        }
    }
    

    public class Log : ViewModelBase
    {
        public Log(string theme, string content, string time, string date)
        {
            Theme = theme;
            Content = content;
            Time = time;
            Date = date;
        }

        public string Theme { get; set; }
        public string Content { get; set; }
        public string Time { get; set; }
        public string Date { get; set; }
    }
}
