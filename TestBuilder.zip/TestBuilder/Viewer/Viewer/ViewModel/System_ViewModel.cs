﻿using Sample1.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Viewer.Model;

using Viewer.Common;
using static Viewer.Common.Mediator1;
using static Viewer.Model.IOM_Info;
using System.Windows;

namespace Viewer.ViewModel
{
    public class System_ViewModel : ViewModelBase
    {
        private IOM_Info _info;
        public IOM_Info Info { get { return _info; } set { _info = value; OnPropertyChanged("Info"); } }
        public ICommand ShowInfoCommand { get; private set; }   //Change Page(View) & Show Info
        public ObservableCollection<IOM_Info> IOMLIST { get { return IOM_List; } set { IOM_List = value; OnPropertyChanged("IOMLIST"); } }
        public System_ViewModel()
        {
            ShowInfoCommand = new RelayCommad<Object>(ShowInfoCommandMethod);
            Register("SETDATA", SetData);
            Register("SETINFO", SetInfo);
            Register("DATAUPDATE", DataUpdate);
            Info = IOM_List[0];
        }
        private void ShowInfoCommandMethod(object parameter)
        {
            NotifyColleagues("SHOWINFO", "asd");
            NotifyColleagues("SETINFO", EWS);

        }

        public void SetData(object obj)
        {
            string str = obj as string;

            string[] SplitLevel1 = str.Split("<<");
            string[] SplitLevel2;
            for (int i = 0; i < IOM_List.Count; i++)
            {
                SplitLevel2 = SplitLevel1[i].Split(';');

                IOMLIST[i].Data.IsRunning = stringtobool(SplitLevel2[1]);
                IOMLIST[i].Data.InfoPortState = SplitLevel2[2];
                IOMLIST[i].Data.ControlPortState = SplitLevel2[3];
                IOMLIST[i].Data.BackPortState = SplitLevel2[4];
                IOMLIST[i].Data.Memory = double.Parse(SplitLevel2[5]);
                IOMLIST[i].Data.Data1 = int.Parse(SplitLevel2[6]);
                IOMLIST[i].Data.Data2 = int.Parse(SplitLevel2[7]);
                IOMLIST[i].Data.Data3 = int.Parse(SplitLevel2[8]);
                IOMLIST[i].Warning = WarningData(IOMLIST[i]);
            }
            DataUpdate("-");
        }
        public void DataUpdate(object obj)
        {

            DispatcherService.Invoke((System.Action)(() =>
            {
                OnPropertyChanged("IOMLIST");
                OnPropertyChanged("Info");
                Console.WriteLine("DataUpdate");
            }));
        }
        public bool stringtobool(string str)
        {
            if (str == "True")
            {
                return true;
            }
            else
                return false;
        }
        public void SetInfo(object obj)
        {
            Info = (IOM_Info)obj;
        }
        public string WarningData(IOM_Info info)
        {
            string str=string.Empty;
            if (info.Data.Memory < info.Data.SettingValue_Memory.Low || info.Data.Memory > info.Data.SettingValue_Memory.High)
                str += "Memory\n";
            if (info.Data.Data1 < info.Data.SettingValue_Data1.Low || info.Data.Data1 > info.Data.SettingValue_Data1.High)
                str += "Data1\n";
            if (info.Data.Data2 < info.Data.SettingValue_Data2.Low || info.Data.Data2 > info.Data.SettingValue_Data2.High)
                str += "Data2\n";
            if (info.Data.Data3 < info.Data.SettingValue_Data3.Low || info.Data.Data3 > info.Data.SettingValue_Data3.High)
                str += "Data3\n";
            return str;
        }
    }
}
