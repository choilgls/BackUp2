﻿using Sample1.Common;

using Viewer.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Viewer.Model;
using Viewer.View.Monitoring;
using Viewer.View.Setting;
using static Viewer.Common.Mediator1;
using System.Collections;
using static Viewer.Model.IOM_Info;

namespace Viewer.ViewModel
{

    public class Main_ViewModel : ViewModelBase
    {
        SharedMemoryHelper sharedMemoryHelper=new SharedMemoryHelper();
        private GridValue _g_Value;
        public GridValue G_Value { get { return _g_Value; } set { _g_Value = value; OnPropertyChanged("G_Value"); } }

        private string _setIndex;                                  //Index
        public string SetIndex { get { return _setIndex; } set { _setIndex = value; OnPropertyChanged("SetIndex"); } }

        private string _exitIndex;                                  //Index
        public string ExitIndex { get { return _exitIndex; } set { _exitIndex = value; OnPropertyChanged("ExitIndex"); } }

        private string _pageName;                                  //Page Name
        public string PageName { get { return _pageName; } set { _pageName = value; OnPropertyChanged("PageName"); } }

        private string _pageSource;                                  //Page Source
        public string PageSource { get { return _pageSource; } set { _pageSource = value; OnPropertyChanged("PageSource"); } }

        public ICommand SettingCommand { get; private set; }   //Change Page(View)
        public ICommand ResultCommand { get; private set; }   //Change Page(View)
        public ICommand ExitCommand { get; private set; }   //Change Page(View)
        public ICommand ChangeViewCommand { get; private set; }   //Change Page(View)
        public ICommand ChangeGridCommand { get; private set; }   //Change Grid
        public Main_ViewModel()
        {
            Init();
            
            ChangeViewCommand = new RelayCommad<Object>(ChangeViewCommandMethod);
            ChangeGridCommand = new RelayCommad<Object>(ChangeGridCommandMethod);
            SettingCommand = new RelayCommad<Object>(SettingCommandMethod);
            ExitCommand = new RelayCommad<Object>(ExitCommandMethod);
            ResultCommand = new RelayCommad<Object>(ResultCommandMethod);
            PageName = "SystemView";
            PageSource = "Monitoring/"+ PageName + ".xaml";
            G_Value = new GridValue("3*", "0", "0");
            SettingSetIndex("0");
            SettingExitIndex("0");
        }
        private void Init()
        {
            IOM_List.Clear();
            IOM_List.Add(new IOM_Info("CPM", "", "192.168.0.10", "0", 0));
            IOM_List.Add(new IOM_Info("IOM", "(Raspi)", "192.168.0.11", "1", 1));
            IOM_List.Add(new IOM_Info("IOM", "(Raspi)", "192.168.0.12", "2", 2));
            IOM_List.Add(new IOM_Info("IOM", "(Raspi)", "192.168.0.13", "3", 3));
            IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.14", "4", 4));
            sharedMemoryHelper.Read();

            Register("SHOWINFO", ShowInfo);
            Register("SETINDEX", SettingSetIndex);
            Register("SETTINGEXITINDEX", SettingExitIndex);
        }
        private void ResultCommandMethod(object parameter)
        {
            string str = parameter as string;
            if (str == "Y")
                Application.Current.Shutdown();
            else
                SettingExitIndex("0");
        }
        private void ExitCommandMethod(object parameter)
        {
            SettingExitIndex("2");
        }
        private void SettingCommandMethod(object parameter)
        {
            SettingWindow window = new SettingWindow();
            SettingSetIndex("2");
            window.ShowDialog();
        }
        private void ChangeGridCommandMethod(object parameter)
        {
            ChangeGrid(parameter);
        }
        private void ChangeViewCommandMethod(object parameter)
        {
            string str=parameter as string;
            if ( str!= null)
            {
                if (PageName.Contains(str))
                    return;
            }

            if(PageName == "DataView")
            {
                this.PageName = "SystemView";
                G_Value.SetPageName("SystemView");
            }                
            else
            {
                G_Value.SetValue("3*", "0", "0");
                this.PageName = "DataView";
                G_Value.SetPageName("DataView");
            }
            
            PageSource = "Monitoring/" + PageName + ".xaml";
        }

        public void ChangeGrid(object obj)
        {
            if (G_Value.V2Value == "0")
            {
                G_Value.SetValue("3*", "auto", "*");
            }
            else
            {
                G_Value.SetValue("3*", "0", "0");
            }
        }
        public void ShowInfo(object obj)
        {
            if (G_Value.V2Value == "0")
                ChangeGrid(obj);
        }
        public void SettingSetIndex(object obj)
        {
            SetIndex = obj as string;
        }
        public void SettingExitIndex(object obj)
        {
            SetIndex = obj as string;
            ExitIndex = obj as string;
        }
    }
}
