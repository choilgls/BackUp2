﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using Viewer.Common;
using Viewer.Model;
using Viewer.View;
using static Viewer.Common.Data;
using static Viewer.Model.User;
using static Viewer.Common.ProcessHelper;

namespace Viewer.ViewModel
{
    public class Login_ViewModel : ViewModelBase
    {
        private bool _iDChecked;                                  //IDChecked
        public bool IDChecked { get { return _iDChecked; } set { _iDChecked = value; OnPropertyChanged("IDChecked"); } }

        private string _iD;                                  //Index
        public string ID { get { return _iD; } set { _iD = value; OnPropertyChanged("ID"); } }

        private string _pW;                                  //Index
        public string PW { get { return _pW; } set { _pW = value; OnPropertyChanged("PW"); } }
        public ICommand LoginCommand { get; private set; }
        public Login_ViewModel()
        {
            
            user = new Model.User(Data.Default.Name, Data.Default.Rank, Data.Default.ID, Data.Default.PW, Data.Default.SaveChecked, Data.Default.Authority);
            LoginCommand = new RelayCommad<Object>(LoginCommandMethod);
            if (user.SaveChecked)
            {
                IDChecked = user.SaveChecked;
                ID = user.ID;
            }
        }
        private void LoginCommandMethod(object parameter)
        {
            if (ID != null || PW != null)
            {
                if (ID == user.ID && PW == user.PW)
                {
                    if (ID == user.ID && PW == user.PW)
                    {
                       /* if (PH.CheckProcess())
                        {
                            PH.StartProcess();
                        }*/
                        user.SaveChecked = IDChecked;
                        Data.Default.SaveChecked = user.SaveChecked;
                        Data.Default.Save();
                        Pass();
                        
                    }
                }
                else
                    MessageBox.Show("ID / PW 다시 입력하시오.");
            }
            else
                MessageBox.Show("ID / PW를 입력해주세요.");
        }
        public void Pass()
        {
            Main main = new Main();
            Window CurrentWindow = Application.Current.MainWindow;
            CurrentWindow.Close();
            main.Show();
        }
    }
}
