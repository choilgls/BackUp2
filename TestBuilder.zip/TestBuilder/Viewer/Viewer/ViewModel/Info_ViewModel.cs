﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Viewer.Model;
using static Viewer.Common.Mediator1;
using static Viewer.Model.IOM_Info;

namespace Viewer.ViewModel
{
    public class Info_ViewModel : ViewModelBase
    {
        private IOM_Info _info;
        public IOM_Info Info { get { return _info; } set { _info = value; OnPropertyChanged("Info"); } }
        public Info_ViewModel()
        {
           // Register("SETINFO", SetInfo);
            Info = IOM_List[0];
        }
        public void SetInfo(object obj)
        {
            Info = (IOM_Info)obj;
        }

        public void InfoViewUpdate(object obj)
        {

        }
    }
}
