﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using Viewer.Model;

namespace Viewer.Common.Converter
{
    public class BGC_Converter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null)
            {
                return "Yellow";
            }
            
            MonitoringData monitoringData = (MonitoringData)value;
            string param = System.Convert.ToString(parameter);
            int target = 0;
            int high = 0;
            int low = 0;
            
            if (param != null)
            {
                if (param == "BTN")
                {
                    if (monitoringData.IsRunning)
                        return "#1F4E79";
                    else
                        return "#444444";
                }
                if (param == "DATA1")
                {
                    high = monitoringData.SettingValue_Data1.High;
                    low = monitoringData.SettingValue_Data1.Low;
                    target = monitoringData.Data1;
                }
                else if (param == "DATA2")
                {
                    high = monitoringData.SettingValue_Data2.High;
                    low = monitoringData.SettingValue_Data2.Low;
                    target = monitoringData.Data2;
                }
                else
                {
                    high = monitoringData.SettingValue_Data3.High;
                    low = monitoringData.SettingValue_Data3.Low;
                    target = monitoringData.Data3;
                }
                if (low <= target && target <= high)
                {
                    return "Black";
                }
                else
                {
                    return "Red";
                }
            }
            return "Yellow";
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
