﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using Viewer.Model;

namespace Viewer.Common.Converter
{
    public class WarningConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            MonitoringData monitoringData = (MonitoringData)value;
            string str = string.Empty;
            if (monitoringData.IsRunning)
            {
                if (monitoringData.Memory < monitoringData.SettingValue_Memory.Low || monitoringData.Memory > monitoringData.SettingValue_Memory.High)
                    str += "Memory\n";
                if(monitoringData.Data1<monitoringData.SettingValue_Data1.Low||monitoringData.Data1>monitoringData.SettingValue_Data1.High)
                    str+= "Data1\n";
                if (monitoringData.Data2 < monitoringData.SettingValue_Data2.Low || monitoringData.Data2 > monitoringData.SettingValue_Data2.High)
                    str += "Data2\n";
                if (monitoringData.Data3 < monitoringData.SettingValue_Data3.Low || monitoringData.Data3 > monitoringData.SettingValue_Data3.High)
                    str += "Data3\n";
            }

            return str;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
