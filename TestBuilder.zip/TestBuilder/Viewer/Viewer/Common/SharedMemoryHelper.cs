﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Shapes;
using static Viewer.Common.Mediator1;
using static Viewer.Common.ProcessHelper;

namespace Viewer.Common
{
    public class SharedMemoryHelper
    {
        public SharedMemoryHelper()
        {
        }
        public void Read()
        {
            Task task = Task.Run(() => HandleGetInfo());
            
        }
        private  async Task HandleGetInfo()
        {
            
            string previousMessage = string.Empty;
            
            while (true)
            {
                //MessageBox.Show(previousMessage);
                try
                {
                    using (var mmf = MemoryMappedFile.OpenExisting("TestBuilder"))
                    {
                        using (var accessor = mmf.CreateViewAccessor())
                        {
                            byte[] buffer = new byte[1000];
                            accessor.ReadArray<byte>(0, buffer, 0, buffer.Length);
                            string newMessage = Encoding.ASCII.GetString(buffer).Trim('\0');
                            Console.WriteLine(newMessage);
                            if (newMessage!= previousMessage)
                            {
                                previousMessage = newMessage;
                                NotifyColleagues("ADDLOG", "Log!@# SharedMemory Get Data :" + newMessage);
                                
                                if (newMessage.Contains("<<"))
                                    NotifyColleagues("SETDATA", newMessage);

                            }

                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("MemoryMappedFile with name - TestBuilder does not exist.\n wait...");
                    PH.KillProcess();
                    PH.StartProcess();   //C:\works\TestBuilder\Agent\Agent\bin\Debug\net6.0-windows\\Agnet.exe
                    Thread.Sleep(3000);
                }
                Thread.Sleep(500);
            }
        }

    }
}
