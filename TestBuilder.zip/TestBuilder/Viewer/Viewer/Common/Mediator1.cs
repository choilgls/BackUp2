﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Viewer.ViewModel;

namespace Viewer.Common
{
    static public class Mediator1
    {
        static IDictionary<string, Action<object>> action = new Dictionary<string, Action<object>>();
        static public System_ViewModel system_ViewModel = new System_ViewModel();

        //등록 또는 덮어쓰기
        static public void Register(string token, Action<object> callback)
        {
            if (!action.ContainsKey(token))
            {
                action.Add(token, callback);
            }
        }

        //해제
        static public void Unregister(string token, Action<object> callback)
        {
            if (action.ContainsKey(token))
                action.Remove(token);
        }

        //호출하기
        static public void NotifyColleagues(string token, object args)
        {
            if (action.ContainsKey(token))
                action[token].Invoke(args);

        }


    }
}
