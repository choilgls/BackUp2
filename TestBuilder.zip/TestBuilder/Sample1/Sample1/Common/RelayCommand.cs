﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Input;

namespace Sample1.Common
{
    public class RelayCommad<T> : ICommand
    {
        readonly Action<T>? _execute = null;
        readonly Predicate<T>? _canExecute = null;

        public RelayCommad(Action<T> execute)
        {
            _execute = execute;
            _canExecute = null;
        }

        public RelayCommad(Action<T> execute, Predicate<T> canExecute)
        {
            _execute = execute;
            _canExecute = canExecute;
        }

        public event EventHandler? CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested += value; }
        }

        public bool CanExecute(object? parameter)
        {
            return true;
        }

        public void Execute(object? parameter)
        {
            _execute((T)parameter);
        }
    }
}
