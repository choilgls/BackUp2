﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Sample1.Common
{
    
    public class Client_Info
    {



        public TcpClient Client;
        public int Num;
        public string Name;
        public static ObservableCollection<string> _ChattList = new ObservableCollection<string>();

        public Client_Info(TcpClient client )
        {
            Client = client;
            Name = client.Client.RemoteEndPoint.ToString().Split(':')[1];

        }
    }
}
