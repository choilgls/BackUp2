﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;
using static Sample1.Common.Mediator;

namespace Sample1.Model
{
    public class MainViewModel :ViewModelBase
    {
        MultiSocketServer multiSocketServer = new MultiSocketServer();
        public ICommand StartStopCommand { get; private set; }   //Start-Stop Button Command
        public ICommand SendCommand { get; private set; }   //Start-Stop Button Command
        public ICommand GetInfoCommand { get; private set; }   //Start-Stop Button Command
        public MainViewModel()
        {
            StartStopCommand = new RelayCommad<Object>(StartStopCommandMethod);
            SendCommand = new RelayCommad<Object>(SendCommandMethod);
            GetInfoCommand = new RelayCommad<Object>(GetInfoCommandMethod);
            SS_Content = "Start";
            SS_BackColor = Brushes.CadetBlue;
        }
        private void GetInfoCommandMethod(object parameter)
        {
            NotifyColleagues("SEND", "INFO");
        }
        private void SendCommandMethod(object parameter)
        {
            NotifyColleagues("SEND", "Server Start");
        }
        private void StartStopCommandMethod(object parameter)
        {
            if(SS_Content == "Start")
            {
                NotifyColleagues("ADDLOG", "Server Start");
                SS_Content = "Stop"; 
                SS_BackColor = Brushes.OrangeRed;
                multiSocketServer.Start();
                multiSocketServer.StartCheckingClientsStatus();
            }
            else
            {
                
                NotifyColleagues("ADDLOG", "Server Stop");
                SS_Content = "Start";
                SS_BackColor = Brushes.CadetBlue;
                multiSocketServer.Stop();
            }
            
        }


        private string _ss_Content;                                  //Start-Stop Button Content
        public string SS_Content { get { return _ss_Content; } set { _ss_Content = value; OnPropertyChanged("SS_Content"); } }

        private Brush _ss_BackColor;                                  //Start-Stop Button Background Color
        public Brush SS_BackColor { get { return _ss_BackColor; } set { _ss_BackColor = value; OnPropertyChanged("SS_BackColor"); } }
    }
}
