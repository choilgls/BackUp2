﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Sample1.ViewModel
{
    public class RoomViewModel : ViewModelBase
    {
        
        public RoomViewModel(TcpClient client)
        {
            Name = client.Client.RemoteEndPoint.ToString().Split(':')[1];
        }
        
        /*public ObservableCollection<string> ChattList
        {
            get
            {
                return ;
            }
            set
            {
                _chattList = value;
                OnPropertyChanged("LogList");
            }
        }*/

        private string _name;                                  //Chatting Room Name
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged("Name"); } }
    }
}
