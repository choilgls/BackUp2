﻿using Agent.Common;
using Agent.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using static Agent.Model.IOM_Info;
using static Agent.Common.MultiSocketServer;
using static Agent.Common.Mediator;
using Microsoft.Win32;
using System.Diagnostics;

namespace Agent.ViewModel
{
    public class ViewModel : ViewModelBase
    {
        static int Num = 0;
        SharedMemoryHelper sharedMemoryHelper=new SharedMemoryHelper();
        public ObservableCollection<IOM_Info> MW_IOM_List { get { return IOM_List; } set { IOM_List = value; OnPropertyChanged("MW_IOM_List"); } }
        MultiSocketServer testserver = new MultiSocketServer();

        private string _test;
        public string Test { get { return _test; } set { _test = value; OnPropertyChanged("Test"); } }


       
        public ICommand SetCommand { get; private set; }   //Change Page(View) & Show Info
        public ViewModel()
        {
            if (Num == 0)
            {
                /*IOM_List.Clear();
            IOM_List.Add(new IOM_Info("CPM", "", "192.168.0.214", "0", 0));
            IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.1", "1", 1));
            IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.2", "2", 2));
            IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.3", "3", 3));
            IOM_List.Add(new IOM_Info("IOM", "(Arduino)", "192.168.0.4", "4", 4));
            SetCommand = new RelayCommad<Object>(SetCommandMethod);
            Data0 = IOM_List[0].Data;
            Data1 = IOM_List[1].Data;
            Data2 = IOM_List[2].Data;
            Data3 = IOM_List[3].Data;
            Data4 = IOM_List[4].Data;*/
                MW_IOM_List.Clear();
                MW_IOM_List.Add(new IOM_Info("CPM", "", "192.168.0.214", "0", 0));
                MW_IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.1", "1", 1));
                MW_IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.2", "2", 2));
                MW_IOM_List.Add(new IOM_Info("IOM", "(STM)", "192.168.0.3", "3", 3));
                MW_IOM_List.Add(new IOM_Info("IOM", "(Arduino)", "192.168.0.4", "4", 4));
                SetCommand = new RelayCommad<Object>(SetCommandMethod);
                Test = "--";
                Register("SETDATA", SetData);
                sharedMemoryHelper.Write();
                Task.Run(() => testserver.OneClient());
                Num++;
            }
            


        }
        private void SetCommandMethod(object parameter)
        {
            string str = string.Empty;
           foreach (var item in IOM_List)
            {
                str+=item.Data.GetAllData(item.Data)+"<<";
            }
            SharedMemoryHelper.Message = "메세지";
            MessageBox.Show(str);

        }
        
        public void SetData(object obj)
        {
            string str = obj as string;
            
            string[] SplitLevel1 = str.Split("<<");
            string[] SplitLevel2;
            for (int i = 0; i < MW_IOM_List.Count; i++)
            {
                SplitLevel2 = SplitLevel1[i].Split(';');
                
                MW_IOM_List[i].Data.ID=int.Parse(SplitLevel2[0]);
                MW_IOM_List[i].Data.IsRunning = stringtobool(SplitLevel2[1]);
                MW_IOM_List[i].Data.InfoPortState = SplitLevel2[2];
                MW_IOM_List[i].Data.ControlPortState = SplitLevel2[3];
                MW_IOM_List[i].Data.BackPortState = SplitLevel2[4];
                MW_IOM_List[i].Data.Memory = double.Parse(SplitLevel2[5]);
                MW_IOM_List[i].Data.Data1 = int.Parse(SplitLevel2[6]);
                MW_IOM_List[i].Data.Data2 = int.Parse(SplitLevel2[7]);
                MW_IOM_List[i].Data.Data3 = int.Parse(SplitLevel2[8]);
               
            }
            SharedMemoryHelper.Message = str;
            DispatcherService.Invoke((System.Action)(() =>
            {
                OnPropertyChanged("MW_IOM_List");
            }));
        }
        public bool stringtobool(string str)
        {
            if (str=="True")
            {
                return true;
            }
            else
                return false;
        }
       
    }
}
