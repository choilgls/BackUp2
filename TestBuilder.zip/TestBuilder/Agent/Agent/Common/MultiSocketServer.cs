﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Agent.Common.Mediator;
using System.Windows.Markup;
using Agent.View;
using System.Windows.Threading;
using System.Diagnostics;
using Agent.ViewModel;
using System.Windows;

namespace Agent.Common
{
    public class MultiSocketServer
    {

        private TcpListener listener;
        private const int BUFFER_SIZE = 1024;
        IPAddress ipAddress = IPAddress.Parse("192.168.0.148");
        int port = 4567;


        public void OneClient()
        {
            listener = new TcpListener(ipAddress, port);

            listener.Start();

            TcpClient client = listener.AcceptTcpClient();
            string ip = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
            MessageBox.Show(ip);
            Task.Run(() => StartCheckingClientsStatus(client));
            try
            {
                // Receive data from the client
                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesRead = 0;

                NetworkStream stream = client.GetStream();
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    NotifyColleagues("SETDATA", data);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
            finally
            {
                client.Close();
            }

        }
        private async Task CheckClientsStatus(TcpClient client)
        {
            while (true)
            {
                await Task.Delay(5000); // wait 5 seconds

                /*lock (client_Infos)
                {
                    // check all clients
                    foreach (var info in client_Infos)
                    {
                        if (info.Client.Client.Poll(0, SelectMode.SelectRead) && info.Client.Client.Receive(new byte[1], SocketFlags.Peek) == 0)
                        {
                            //NotifyColleagues("ADDLOG", "Client disconnected : " + client.Client.RemoteEndPoint);
                            NotifyColleagues("ADDLOG", info.Client.Client.RemoteEndPoint.ToString().Split(':')[1] + " - Client disconnected");
                            //Console.WriteLine("Client disconnected: {0}", client.Client.RemoteEndPoint);
                            info.Client.Close();
                            client_Infos.Remove(info);
                        }
                    }
                }*/
                if (client.Client.Poll(0, SelectMode.SelectRead) && client.Client.Receive(new byte[1], SocketFlags.Peek) == 0)
                {
                    client.Close();
                    
                }
            }
        }

        public void StartCheckingClientsStatus(TcpClient client)
        {
            Task.Run(() => CheckClientsStatus(client));
        }

    }
}
