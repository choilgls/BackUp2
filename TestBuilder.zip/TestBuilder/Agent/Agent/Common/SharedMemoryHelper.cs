﻿using Agent.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using static Agent.Common.Mediator;
using static Agent.Model.IOM_Info;

namespace Agent.Common
{
    public class SharedMemoryHelper
    {
        static public string Message = "Message";
        public SharedMemoryHelper()
        {
        }

        public async void Write()
        {
            await Task.Run(() => HandleSetInfo());
        }
        private async Task HandleSetInfo()
        {
            using (var mmf = MemoryMappedFile.CreateOrOpen("TestBuilder", 1000))
            {
                using (var accessor = mmf.CreateViewAccessor())
                {
                    while(true)
                    {
                        string message = Message;
                        byte[] buffer = Encoding.ASCII.GetBytes(message);
                        accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                        //Console.WriteLine($"Sent message: {message}");
                        System.Threading.Thread.Sleep(500);
                    }
                }
            }

        }

        

    }
}
