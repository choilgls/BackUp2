﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Xml.Linq;


namespace Agent.Model
{
    
    public class MonitoringData:INotifyPropertyChanged
    {
        public MonitoringData(string name,int id)
        {
            Name = name;
            ID = id;
            IsRunning = false;
            InfoPortState = "-";
            ControlPortState = "-";
            BackPortState = "-";
            Memory = 0;
            Data1 = 0;
            Data2 = 0;
            Data3 = 0;
        }

        private string name { get; set; }      //true false
        private int id { get; set; }    //1000~2000
        private bool isRunning { get; set; }      //true false
        private string infoPortState { get; set; }      //정상 비정상
        private string controlPortState { get; set; }    //정상 비정상
        private string backPortState { get; set; }    //정상 비정상
        private double memory { get; set; }       //1024 ~ 2048
        private int data1 { get; set; }    //10~20
        private int data2 { get; set; }    //100~200
        private int data3 { get; set; }    //1000~2000

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public int ID
        {
            get { return id; }
            set
            {
                if (id != value)
                {
                    id = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }
        public bool IsRunning
        {
            get { return isRunning; }
            set
            {
                if (isRunning != value)
                {
                    isRunning = value;
                    OnPropertyChanged(nameof(IsRunning));
                }
            }
        }
        public string InfoPortState
        {
            get { return infoPortState; }
            set
            {
                if (infoPortState != value)
                {
                    infoPortState = value;
                    OnPropertyChanged(nameof(InfoPortState));
                }
            }
        }
        public string ControlPortState
        {
            get { return controlPortState; }
            set
            {
                if (controlPortState != value)
                {
                    controlPortState = value;
                    OnPropertyChanged(nameof(ControlPortState));
                }
            }
        }
        public string BackPortState
        {
            get { return backPortState; }
            set
            {
                if (backPortState != value)
                {
                    backPortState = value;
                    OnPropertyChanged(nameof(BackPortState));
                }
            }
        }
        public double Memory
        {
            get { return memory; }
            set
            {
                if (memory != value)
                {
                    memory = value;
                    OnPropertyChanged(nameof(Memory));
                }
            }
        }
        public int Data1
        {
            get { return data1; }
            set
            {
                if (data1 != value)
                {
                    data1 = value;
                    OnPropertyChanged(nameof(Data1));
                }
            }
        }
        public int Data2
        {
            get { return data2; }
            set
            {
                if (data2 != value)
                {
                    data2 = value;
                    OnPropertyChanged(nameof(Data2));
                }
            }
        }
        public int Data3
        {
            get { return data3; }
            set
            {
                if (data3 != value)
                {
                    data3 = value;
                    OnPropertyChanged(nameof(Data3));
                }
            }
        }

        public string GetAllData(MonitoringData target)
        {
            List<PropertyInfo> Properties = typeof(MonitoringData).GetProperties().ToList();
            string str = string.Empty;
            foreach (PropertyInfo property in Properties)
            {
                if (property.Name != "Name")
                {
                    object value = property.GetValue(target);
                    str += value + ";";
                }
                    
                
            }
            return str;
        }
        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
