﻿using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Read
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var mmf = MemoryMappedFile.CreateOrOpen("TestBuilder", 1000))
            {
                using (var accessor = mmf.CreateViewAccessor())
                {
                    for (int i = 0; i < 10; i++)
                    {
                        string message = $"Message {i}";
                        byte[] buffer = Encoding.ASCII.GetBytes(message);
                        accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                        Console.WriteLine($"Sent message: {message}");
                        System.Threading.Thread.Sleep(1000);
                    }
                }
            }

            Console.WriteLine("Done.");
            Console.ReadLine();
        }
    }
}
