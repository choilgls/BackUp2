﻿using System;
using System.Collections.Generic;
using System.IO.MemoryMappedFiles;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Write
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (var mmf = MemoryMappedFile.CreateOrOpen("TestBuilder", 1000))
            {
                using (var accessor = mmf.CreateViewAccessor())
                {
                    for (int i = 0; i < 100; i++)
                    {
                        byte[] buffer = new byte[1000];
                        accessor.ReadArray<byte>(0, buffer, 0, buffer.Length);
                        string message = Encoding.ASCII.GetString(buffer).Trim('\0');
                        Console.WriteLine($"Received message: {message}");
                        System.Threading.Thread.Sleep(1000);
                    }
                }
            }

            Console.WriteLine("Done.");
            Console.ReadLine();
        }
    }
}
