﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Sample1.Common
{
    public class TextData : INotifyPropertyChanged
    {
        private bool _condition;
        private string _position;
        private string _background;

        private string _text;
        private string _textPosition;
        
        private string _time;
        private string _timePosition;


        

        public event PropertyChangedEventHandler PropertyChanged;

        public bool Condition
        {
            get { return _condition; }
            set
            {
                _condition = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Condition)));
            }
        }
        public string Position
        {
            get { return _position; }
            set
            {
                _position = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Position)));
            }
        }
        public string Background
        {
            get { return _background; }
            set
            {
                _background = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Background)));
            }
        }

        public string Text
        {
            get { return _text; }
            set
            {
                _text = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Text)));
            }
        }
        public string TextPosition
        {
            get { return _textPosition; }
            set
            {
                _textPosition = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TextPosition)));
            }
        }
        public string Time
        {
            get { return _time; }
            set
            {
                _time = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Time)));
            }
        }
        public string TimePosition
        {
            get { return _timePosition; }
            set
            {
                _timePosition = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TimePosition)));
            }
        }

        public TextData()
        {

        }

        public void ButtonClicked()
        {
            MessageBox.Show("Button Clicked!");
        }
    }
}
