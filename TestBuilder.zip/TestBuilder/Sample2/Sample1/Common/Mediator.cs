﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample1.Common
{
    static public class Mediator
    {
        static IDictionary<string, Action<object>> action = new Dictionary<string, Action<object>>();
        

        //등록 또는 덮어쓰기
        static public void Register(string token, Action<object> callback)
        {
            if (!action.ContainsKey(token))
            {
                action.Add(token, callback);
            }
        }

        //해제
        static public void Unregister(string token, Action<object> callback)
        {
            if (action.ContainsKey(token))
                action.Remove(token);
        }

        //호출하기
        static public void NotifyColleagues(string token, object args)
        {
            if (action.ContainsKey(token))
                action[token].Invoke(args);

        }


    }
}
