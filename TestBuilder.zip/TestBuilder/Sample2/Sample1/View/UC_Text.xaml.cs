﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Sample1.View
{
    /// <summary>
    /// UC_Text.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Text : UserControl
    {
        public UC_Text()
        {
            InitializeComponent();
        }

        //========================Position========================
        public static readonly DependencyProperty PositionProperty =
            DependencyProperty.Register("Position", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string Position
        {
            get { return (string)GetValue(PositionProperty); }
            set { SetValue(PositionProperty, value); }
        }

        //========================Background========================
        public static readonly DependencyProperty BackgroundProperty =
            DependencyProperty.Register("Background", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string Background
        {
            get { return (string)GetValue(BackgroundProperty); }
            set { SetValue(BackgroundProperty, value); }
        }

        //========================Text========================
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        //========================TextPosition========================
        public static readonly DependencyProperty TextPositionProperty =
            DependencyProperty.Register("TextPosition", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string TextPosition
        {
            get { return (string)GetValue(TextPositionProperty); }
            set { SetValue(TextPositionProperty, value); }
        }

        //========================Time========================
        public static readonly DependencyProperty TimeProperty =
            DependencyProperty.Register("Time", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string Time
        {
            get { return (string)GetValue(TimeProperty); }
            set { SetValue(TimeProperty, value); }
        }

        //========================TimePosition========================
        public static readonly DependencyProperty TimePositionProperty =
            DependencyProperty.Register("TimePosition", typeof(string), typeof(UserControl1), new PropertyMetadata(""));
        public string TimePosition
        {
            get { return (string)GetValue(TimePositionProperty); }
            set { SetValue(TimePositionProperty, value); }
        }
    }
}
