﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Markup;
using static Sample1.Common.Mediator;
using static Sample1.Common.TextData;

namespace Sample1.ViewModel
{
    public class RoomViewModel : ViewModelBase
    {
        Client_Info Client;
        public ICommand SendCommand { get; private set; }   //Send Button Command
        public ICommand CloseCommand { get; private set; }   //Send Button Command
        public RoomViewModel(Client_Info client)
        {
            Client = client;
            Name = Client.Client.Client.RemoteEndPoint.ToString().Split(':')[1];
            //Name = ((IPEndPoint)client.Client.Client.RemoteEndPoint).Address.ToString();
            SendCommand = new RelayCommad<Object>(SendCommandMethod);
            CloseCommand = new RelayCommad<Object>(CloseCommandMethod);
        }
        
        public ObservableCollection<TextData> ChattList
        {
            get
            {
                return Client._ChattList;
            }
            set
            {
                Client._ChattList = value;
                OnPropertyChanged("ChattList");
            }
        }
        private void CloseCommandMethod(object parameter)
        {
            MessageBox.Show("asd");
        }
        private void SendCommandMethod(object parameter)
        {
            
            ChattList.Add(new TextData() { Position = "Right", Background = "Yellow", Text = Text, TextPosition = "Right", Time = DateTime.Now.ToString("t"), TimePosition = "Left",Condition=false });
            NotifyColleagues("SENDTO", Name+"!@#$%"+Text);
            Text = "";
        }

        private string _text;                                  //Start-Stop Button Content
        public string Text { get { return _text; } set { _text = value; OnPropertyChanged("Text"); } }

        private string _name;                                  //Chatting Room Name
        public string Name { get { return _name; } set { _name = value; OnPropertyChanged("Name"); } }
    }
    
}
