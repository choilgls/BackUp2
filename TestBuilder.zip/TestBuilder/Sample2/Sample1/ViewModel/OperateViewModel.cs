﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Sample1.ViewModel
{

    public class OperateViewModel : ViewModelBase
    {
        /*private ObservableCollection<MyDataModel> items;
        public ObservableCollection<MyDataModel> Items
        {
            get { return items; }
            set
            {
                items = value;
                OnPropertyChanged(nameof(Items));
            }
        }*/
        public OperateViewModel()
        {
           
        }
        
    }
}
